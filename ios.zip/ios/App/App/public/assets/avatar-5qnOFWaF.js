const a="/assets/avatar-B3SGDfws.jpg";export{a};
