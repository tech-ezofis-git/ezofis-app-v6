const E=12e4,s=640,N=1280;export{N as S,E as T,s as a};
