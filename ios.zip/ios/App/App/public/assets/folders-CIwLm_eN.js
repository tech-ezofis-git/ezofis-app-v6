import{j as o}from"./index-s2u0jWwc.js";const e=()=>o.jsx("div",{});e.displayName="FoldersPage";function n(){return o.jsx(e,{})}export{n as component};
