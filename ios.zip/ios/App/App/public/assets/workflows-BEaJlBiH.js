import{j as o}from"./index-s2u0jWwc.js";const t=()=>o.jsx(o.Fragment,{});t.displayName="WorkflowsPage";function n(){return o.jsx(t,{})}export{n as component};
