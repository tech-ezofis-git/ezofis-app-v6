import{j as e}from"./index-s2u0jWwc.js";const o=()=>e.jsx("div",{});o.displayName="HelpPage";function n(){return e.jsx(o,{})}export{n as component};
