import{n}from"./index-s2u0jWwc.js";function r(e){return n({select:c=>e!=null&&e.select?e.select(c.location):c.location})}export{r as u};
