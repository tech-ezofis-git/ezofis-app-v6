import{j as t}from"./index-s2u0jWwc.js";const o=({children:r})=>t.jsxs("h3",{className:"mb-8 border-b border-gray-3 pb-2 text-15 font-medium text-gray-12",children:["# ",r]});export{o as S};
