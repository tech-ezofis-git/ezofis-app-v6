import{j as s}from"./index-s2u0jWwc.js";const o=()=>s.jsx("div",{});o.displayName="TasksPage";function e(){return s.jsx(o,{})}export{e as component};
