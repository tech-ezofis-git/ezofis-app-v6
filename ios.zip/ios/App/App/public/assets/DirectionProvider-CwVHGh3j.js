import{r as t}from"./index-s2u0jWwc.js";const e=t.createContext({dir:"ltr",toggleDirection:()=>{},setDirection:()=>{}});function o(){return t.useContext(e)}export{o as u};
