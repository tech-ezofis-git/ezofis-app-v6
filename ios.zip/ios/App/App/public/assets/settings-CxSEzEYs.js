import{j as t}from"./index-s2u0jWwc.js";const e=()=>t.jsx("div",{});e.displayName="SettingsPage";function o(){return t.jsx(e,{})}export{o as component};
