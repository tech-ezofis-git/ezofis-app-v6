import{j as s}from"./index-s2u0jWwc.js";const o=({children:t})=>s.jsx("h2",{className:"mb-10 text-18 font-semibold text-gray-13",children:t});export{o as S};
